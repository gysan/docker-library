typedef struct arcfour_key
{      
   byte state[256];       
   byte i;        
   byte j;
} arcfour_key;

